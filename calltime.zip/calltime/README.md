# Call Time

Android app that reads your phone's call log and shows the total talk time per number
(incoming + outgoing, answered calls only), sorted from most to least. Everything stays on
your phone: the app has no internet permission.

## Get the APK (no Android Studio needed)

1. Create a free account at github.com and make a new repository (private is fine).
2. Upload all the files from this folder, keeping the structure (including the hidden
   `.github` folder).
3. Open the **Actions** tab. The "Build APK" workflow runs by itself (about 3-5 minutes).
   If it does not, open it and tap **Run workflow**.
4. When it finishes, open the run and download the **CallTime-apk** artifact (a zip).
   Unzip it to get `app-debug.apk`.
5. Copy the APK to your Poco X7 Pro and tap it to install. Allow "Install unknown apps"
   for your file manager or browser when asked.
6. Open Call Time and allow the Call log permission.

## Notes

- Matching numbers by their last 9 digits, so `+971 50 123 4567` and `050 123 4567`
  count as the same person.
- Only answered incoming and outgoing calls with a duration above 0 are counted.
- WhatsApp and other app calls are not in the phone's call log, so they are not included.
- If your phone keeps only recent history, the totals cover only what the call log holds.
