package com.omer.calltime

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.CallLog
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {

    data class Entry(
        val key: String,
        var number: String,
        var name: String?,
        var totalSeconds: Long = 0,
        var incomingSeconds: Long = 0,
        var outgoingSeconds: Long = 0,
        var calls: Int = 0
    ) {
        val title: String get() = if (!name.isNullOrBlank()) name!! else if (number.isBlank()) "Unknown / Private" else number
    }

    private val all = ArrayList<Entry>()
    private val shown = ArrayList<Entry>()
    private lateinit var summary: TextView
    private lateinit var message: TextView
    private lateinit var search: EditText
    private lateinit var adapter: ListAdapterImpl

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun fmt(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return buildString {
            if (h > 0) append("${h}h ")
            if (h > 0 || m > 0) append("${m}m ")
            append("${s}s")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "Call Time"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
        })

        summary = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(summary)

        search = EditText(this).apply {
            hint = "Search name or number"
            setSingleLine(true)
        }
        root.addView(search)

        val refresh = Button(this).apply {
            text = "Refresh"
            setOnClickListener { loadOrRequest() }
        }
        root.addView(refresh)

        message = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#B00020"))
            visibility = View.GONE
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(message)

        adapter = ListAdapterImpl()
        val list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            divider = null
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })

        loadOrRequest()
    }

    private fun loadOrRequest() {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) {
            message.visibility = View.GONE
            load()
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            message.visibility = View.GONE
            load()
        } else {
            message.text = "Call log permission is needed to calculate call time. Allow it in Settings > Apps > Call Time > Permissions, then tap Refresh."
            message.visibility = View.VISIBLE
        }
    }

    private fun load() {
        val map = LinkedHashMap<String, Entry>()
        val cols = arrayOf(
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.DURATION,
            CallLog.Calls.TYPE
        )
        try {
            contentResolver.query(CallLog.Calls.CONTENT_URI, cols, null, null, null)?.use { c ->
                val iNum = c.getColumnIndexOrThrow(CallLog.Calls.NUMBER)
                val iName = c.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME)
                val iDur = c.getColumnIndexOrThrow(CallLog.Calls.DURATION)
                val iType = c.getColumnIndexOrThrow(CallLog.Calls.TYPE)
                while (c.moveToNext()) {
                    val type = c.getInt(iType)
                    val dur = c.getLong(iDur)
                    if (dur <= 0) continue
                    if (type != CallLog.Calls.INCOMING_TYPE && type != CallLog.Calls.OUTGOING_TYPE) continue

                    val number = c.getString(iNum) ?: ""
                    val name = c.getString(iName)
                    val digits = number.filter { it.isDigit() }
                    // Match +971 50 123 4567 and 050 123 4567 as the same person by last 9 digits
                    val key = if (digits.length >= 9) digits.takeLast(9) else if (digits.isNotEmpty()) digits else "private"

                    val e = map.getOrPut(key) { Entry(key, number, name) }
                    if (e.name.isNullOrBlank() && !name.isNullOrBlank()) e.name = name
                    e.totalSeconds += dur
                    e.calls += 1
                    if (type == CallLog.Calls.INCOMING_TYPE) e.incomingSeconds += dur else e.outgoingSeconds += dur
                }
            }
        } catch (ex: Exception) {
            message.text = "Could not read call log: ${ex.message}"
            message.visibility = View.VISIBLE
            return
        }

        all.clear()
        all.addAll(map.values.sortedByDescending { it.totalSeconds })
        applyFilter()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(all.filter {
            q.isEmpty() || it.title.lowercase().contains(q) || it.number.contains(q)
        })
        val total = all.sumOf { it.totalSeconds }
        val totalCalls = all.sumOf { it.calls }
        summary.text = "${all.size} contacts · $totalCalls answered calls · ${fmt(total)} total"
        adapter.notifyDataSetChanged()
    }

    inner class ListAdapterImpl : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val e = shown[position]
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(10), 0, dp(10))
            }
            row.addView(TextView(this@MainActivity).apply {
                text = e.title
                textSize = 17f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.BLACK)
            })
            if (!e.name.isNullOrBlank() && e.number.isNotBlank()) {
                row.addView(TextView(this@MainActivity).apply {
                    text = e.number
                    textSize = 13f
                    setTextColor(Color.GRAY)
                })
            }
            row.addView(TextView(this@MainActivity).apply {
                text = fmt(e.totalSeconds)
                textSize = 20f
                setTextColor(Color.parseColor("#1B5E20"))
            })
            row.addView(TextView(this@MainActivity).apply {
                text = "${e.calls} calls · in ${fmt(e.incomingSeconds)} · out ${fmt(e.outgoingSeconds)}"
                textSize = 13f
                setTextColor(Color.DKGRAY)
            })
            return row
        }
    }
}
